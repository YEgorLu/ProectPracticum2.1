export enum pagesURLS{
    MAIN = '/',
    LOGIN = '/login',
    TEACHER_PROFILE = '/teacherProfile',
    SELF_PROFILE = '/profile'
}