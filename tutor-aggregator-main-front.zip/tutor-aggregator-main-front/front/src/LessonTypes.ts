export enum LessonFormat{
    Online,
    Offline
}

export enum DesiredSex{
    Male,
    Female
}

export enum DesiredAge{
    Preschoolers,
    PrimarySchoolers,
    MiddleSchoolers,
    HighSchoolers,
    Students,
    Adults
}